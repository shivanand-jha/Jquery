var allItems = [];
        
function createInputField() {
    // Create a new div element
    var newDiv = document.createElement('div');

    // Create a new label element
    var newLabel = document.createElement('label');
    newLabel.setAttribute('for', 'newItem');
    newLabel.textContent = 'New Item';

    // Create a new input element
    var newInput = document.createElement('input');
    newInput.setAttribute('type', 'text');
    newInput.setAttribute('class', 'items');
    newInput.setAttribute('placeholder', 'New Item...');

    // Append the label and input to the div
    newDiv.appendChild(newLabel);
    newDiv.appendChild(newInput);

    // Insert the new div before the button
    var button = document.querySelector('button');
    button.parentNode.insertBefore(newDiv, button);
}

function submitForm(event) {
    // Prevent the default form submission behavior
    event.preventDefault();

    // Push the new item as an object into the allItems array
    let itemInp = document.getElementsByClassName('items');
    let x = Array.from(itemInp).map((inp) => inp.value.trim());

    allItems.push({
        title: document.getElementById('title').value,
        item: document.getElementById('item').value,
        newitem: x
    });

    // Render the updated list
    renderList();

    // Reset the form
    document.getElementById('todoForm').reset();
}

function renderList() {
    // Create HTML for each item in the allItems array
    var listContent = allItems.map((item, index) => `
        <ul>
            <li>Title: ${item.title}</li>
            <li>Item: ${item.item}${item.newitem.map(newItem => `<li>Item : ${newItem}</li>`).join('')}</li>
            <button class="deleteButton" onclick="deleteItem(${index})">Delete</button>
        </ul>
    `).join('');

    // Display the information in the listContainer
    var listContainer = document.getElementById('listContainer');
    listContainer.innerHTML = listContent;
}

function deleteItem(index) {
    // Remove the item from the allItems array
    allItems.splice(index, 1);

    // Render the updated list
    renderList();
}